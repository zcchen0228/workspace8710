package pkg1;

public class ClassA {
	private void m1() {
	}

	private void m2() {
	}

	private void m3() {
	}

	private void m4() {
	}

	private void m5() {
	}

	private void m6() {
	}
}
