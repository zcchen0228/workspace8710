package pkg1;

public class ClassA {
   public void ma1(int position, String buffer) {
      String dataA = buffer;
      int indexA = position / 100;

      if (indexA < 0) {
         indexA = -1 * indexA;
         System.out.println(dataA.charAt(indexA));
      } else {
         indexA = indexA + 1;
         System.out.println(dataA.charAt(indexA));
      }
   }

   public int ma2(int x, int y) {
      int resultA = 0;
      resultA = x > y ? x - y : y - x;
      return resultA;
   }
}
