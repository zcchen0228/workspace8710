package pkg1;

public class ClassA {
	void foo(int position, String buffer) {
		int x = m1(10);
		int y = m2(10 + x);
		m3(10 + y);
	}

	void bar(int x) {
		int y = m1(x) + m2(10 + x);
		System.out.println(10 + y);
	}

	public int m1(int x) {
		return x;
	}

	public int m2(int x) {
		return x;
	}

	public int m3(int x) {
		return x;
	}
}
