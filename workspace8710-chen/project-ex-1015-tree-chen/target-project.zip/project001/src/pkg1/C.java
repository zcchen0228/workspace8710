package pkg1;

public class C {
	void mc1(String strc1) {}
	void mc2(String strc2, int ict2) {}
}
