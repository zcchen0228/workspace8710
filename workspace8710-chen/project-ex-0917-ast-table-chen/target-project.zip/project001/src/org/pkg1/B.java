package org.pkg1;

public class B {
	void mb1(String str1) {}
	void mb2(String str2, int b2) {}
}
