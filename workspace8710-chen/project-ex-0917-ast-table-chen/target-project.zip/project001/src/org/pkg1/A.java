package org.pkg1;

public class A {
	void ma1(String str1) {}
	void ma2(String str2, int i1) {}
}
