package org.pkg2;

public class F {
	void mf1() {}
	void mf2() {}
}
